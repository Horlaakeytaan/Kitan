import './Header.css'

const Header = () => {
    return (
        <div className='container'>
            
            <section className='logo'>
                <img src="/logo.svg" alt="logo" />
            
                <nav className='navs'>
                    <nav>Features</nav>
                    <nav>Company</nav>
                    <nav>Careers</nav>
                    <nav>About</nav>
                </nav>
                </section>
            <section className='sec2'> 
                <nav>Login</nav>
                <button>Register</button>
                </section>
            
            
            
        </div>
    )
}

export default Header