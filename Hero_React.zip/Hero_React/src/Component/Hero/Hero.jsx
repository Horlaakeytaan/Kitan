import './Hero.css'
import Image from './Image'
import Text from './Text'


const Hero = () => {
    return (
        <div className='hero'> 
            
            <Text/>
            <Image/>
            
        </div>
    )
}

export default Hero