// import heroImage from '../Hero/'

const Image = () => {
    return (
        <div className="mage"> 

            <img src="/image-hero-desktop.png" alt="" width={'500px'} height={'600px'}/>
            
            {/* <img src="/Hero.png" alt="" />  copying from the public file */}
            {/* copying from asset file */}
            {/* <img src="{heroImage}" alt="" /> */}
        </div>
    )
}

export default Image