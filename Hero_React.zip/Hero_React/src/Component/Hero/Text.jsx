

const Text = () => {
    return (
        
        <div className="text">
            <div>
            <h1><b>Make <br />remote work</b></h1>
            <p >Get your team in sync, no matter your location. <br /> Streamline processes, create team rituals, and <br /> watch productivity soar.</p>
            <button>Learn more</button>
            <br /> <br /> <br /><br />
            <div className='foot'>
            <img src="/client-databiz.svg" alt="" />
            <img src="/client-audiophile.svg" alt="" />
            <img src="/client-meet.svg" alt="" />
            <img src="/client-maker.svg" alt="" />
        </div>
           
            
        </div>
        </div>
    )
}

export default Text;