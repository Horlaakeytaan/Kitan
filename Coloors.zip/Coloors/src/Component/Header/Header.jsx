import './Header.css'

const Header = () => {
    return(
        <div className='container'>
        
        <div className='image'><img src="/coloors_logo.svg" alt="" /></div>
        <div>
            <p><b>Skillshare </b>  Explore your creativity with thousands of hands_on <br /> classes. Join Skillshare today and get 30% off. <mark>Learn More</mark> </p> 
        </div>

        <div className='navs'>
            <nav>Tools</nav>
            <nav>Go pro</nav>
            <nav>Sign in</nav>
            <button>Sign up</button>
        </div>
        </div>
    )
}
export default Header