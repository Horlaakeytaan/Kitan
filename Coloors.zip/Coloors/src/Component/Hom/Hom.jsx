import './Hom.css'

const Hom = () => {
    return (
        <div className='hom'>This is Home
            <div className='super'>
                <h1><b>The super fast <br /> color palettes <br /> generator!</b></h1>
                <p>Create the perfect pallette or get inspired by <br /> thousands of beautiful color schemes</p>
                <button className='start'><b>Start the generator</b></button> <br /><br />
                <button className='explore'><b>Explore trending palettes</b></button> <br /><br />
                    <img src="/public/cup.svg" alt="" /> 
            </div>

            <div className='palette'>
               <button> <img src="/public/coloors.png" alt="" width={'650px'} height={'550'} /> </button>
            </div>

        </div>
    )
}
export default Hom