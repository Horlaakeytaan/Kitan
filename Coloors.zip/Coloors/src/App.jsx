import Header from "./Component/Header/Header"
import Hom from "./Component/Hom/Hom"

const App = () => {
  return(
    <div>Hello

      <Header/>
      <Hom/>
    </div>
  )
}
export default App